import { test as setup } from "@playwright/test";
import path from "path";
import LoginHelper from "../../fixture/helper/LoginHelper";

const authFile = path.join(__dirname, "user.json");
setup("authenticate", async ({ page }) => {
  // Perform authentication steps. Replace these actions with your own.
  const login = new LoginHelper(page);
  await login.doLogin();
  await page.context().storageState({ path: authFile });
  await page.waitForLoadState("networkidle");
});
