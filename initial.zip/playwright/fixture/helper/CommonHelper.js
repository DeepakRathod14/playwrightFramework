import { faker } from "@faker-js/faker";

class CommonHelper {
  constructor(page) {
    const page = page;
  }

  /**
   * Get fake name.
   * @returns {string} - The fake name.
   */
  getFakeName = () => {
    return "FAKE_" + faker.string.alphanumeric({ length: 10 });
  };

  /**
   * Get fake number based on length.
   * @param {number} length - The length of the fake number.
   * @returns {number} - The fake number.
   */
  getFakeNumber = (length) => {
    return faker.number({ length: length });
  };

  /**
   * Get fake date and time.
   * @returns {string} - The fake date and time.
   */
  getFakeDateAndTime = () => {
    return faker.date.future().toString();
  };

  /**
   * Get fake date.
   * @returns {string} - The fake date.
   */
  getFakeDate = () => {
    return faker.date.future().toDateString();
  };

  /**
   * Get future fake date and time.
   * @returns {string} - The future fake date and time.
   */
  getFutureFakeDateTime = () => {
    return faker.date.future().toString();
  };

  /**
   * Get future fake date and time in ISO format.
   * @returns {string} - The future fake date and time in ISO format.
   */
  getFutureFakeDateTimeIso = () => {
    return faker.date.future().toISOString();
  };

  /**
   * Get fake description.
   * @returns {string} - The fake description.
   */
  getFakeDescription = () => {
    return "FAKE_DESCRIPTION: " + faker.word.words({ count: 5 });
  };

  /**
   * Get fake message.
   * @param {number} length - The length of the fake message.
   */
  getFakeMessage = (length) => {
    return "FAKE_MESSAGE: " + faker.word.words({ count: length });
  };

  /**
   * Get fake alphanumeric value.
   * @param {number} count - The count of the fake value.
   * @returns {string} - The fake value.
   */
  getFakeValue = (count) => {
    return faker.string.alphanumeric(count);
  };

  /**
   * Get fake UUID.
   * @returns {string} - The fake UUID.
   */
  getFakeUuid = () => {
    return faker.string.uuid();
  };

  /**
   * Get future formatted date
   * @returns {string} - The future formatted date.
   * @example 'Sep 30 2029 11 00 PM'
   */
  getFormattedFakeDate = () => {
    const dateTime = this.getFutureFakeDateTime().split(" ").slice(1, 5);

    //format time
    const time = dateTime[3].split(":");
    let hour =
      parseInt(time[0]) > 12 ? (parseInt(time[0]) - 12).toString() : time[0];
    if (hour.length === 1) hour = "0" + hour;

    return `${dateTime[0]} ${dateTime[1]} ${dateTime[2]} ${hour} ${time[1]} PM`;
  };

  /**
   * Returns value wrapped with data-value attribute.
   */
  wrapDataValue(value) {
    return `[data-value="${value}"]`;
  }

  /**
   * Returns locator wrapped with data-testid attribute.
   * @param {string} locator - The locator to be wrapped.
   * @returns {string} - The wrapped locator.
   */
  wrapDataTestId(locator) {
    return `[data-testid="${locator}"]`;
  }

  /**
   * Get future formateed date for manual patch approval
   * @returns {string} - The future formatted date.
   * @example '09/30/2025-11:00 PM'
   */
  getFormattedDate = () => {
    const dateTime = this.getFutureFakeDateTime().split(" ").slice(1, 5);
    //format time
    const time = dateTime[3].split(":");
    let hour =
      parseInt(time[0]) > 12 ? (parseInt(time[0]) - 12).toString() : time[0];
    if (hour.length === 1) hour = "0" + hour;
    return `${this.getMonthNumber(dateTime[0])}/${dateTime[1]}/${
      dateTime[2]
    }-${hour}:${time[1]} PM`;
  };

  /**
   * Get Month no id 2 digit format from month name
   * @param {*} monthName
   * @returns Month no id
   */
  getMonthNumber = (monthName) => {
    const months = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];
    const monthIndex = months.findIndex((month) =>
      month.toLowerCase().startsWith(monthName.toLowerCase())
    );
    if (monthIndex !== -1) {
      const monthNumber = monthIndex + 1;
      return monthNumber.toString().padStart(2, "0");
      // Adding 1 to match the month numbers (1-12)
      //// Using padStart to ensure 2-digit format with leading zeros
    } else {
      return -1;
      // Return -1 if the month name is not found
    }
  };

  /**
   * Get future formateed date for manual patch approval
   * @returns {string} - The future formatted date.
   * @example '09/30/2025-11:00 PM'
   */
  getFormattedDate = () => {
    const dateTime = this.getFutureFakeDateTime().split(" ").slice(1, 5);
    //format time
    const time = dateTime[3].split(":");
    let hour =
      parseInt(time[0]) > 12 ? (parseInt(time[0]) - 12).toString() : time[0];
    if (hour.length === 1) hour = "0" + hour;
    return `${this.getMonthNumber(dateTime[0])}/${dateTime[1]}/${
      dateTime[2]
    }-${hour}:${time[1]} PM`;
  };

  /**
   * Get Month no id 2 digit format from month name
   * @param {*} monthName
   * @returns Month no id
   */
  getMonthNumber = (monthName) => {
    const months = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];
    const monthIndex = months.findIndex((month) =>
      month.toLowerCase().startsWith(monthName.toLowerCase())
    );
    if (monthIndex !== -1) {
      const monthNumber = monthIndex + 1;
      return monthNumber.toString().padStart(2, "0");
      // Adding 1 to match the month numbers (1-12)
      //// Using padStart to ensure 2-digit format with leading zeros
    } else {
      return -1;
      // Return -1 if the month name is not found
    }
  };

  /**
   * Get month's name from no.
   * @returns {string} - Month name.
   */
  getMonthName = (monthNumber) => {
    const date = new Date();
    date.setMonth(monthNumber - 1);
    // Adjust month number to zero-based index
    return date.toLocaleString("default", { month: "long" });
  };

  /**
   * Get today's date and time.
   * @returns {string} - The future fake date and time.
   */
  getCurrentDate = () => {
    const currentDate = new Date();
    return (
      currentDate.getFullYear() +
      "-" +
      (currentDate.getMonth() + 1) +
      "-" +
      currentDate.getDate()
    );
  };
}
export default CommonHelper;
