export const lctr = {
  appLogoHeader: 'button[data-test-subj="menuWazuhButton"]',
};

export const text = {
  Modules: "Modules",
  SecurityEvents: "Security Events",
  IntegrityMonitoring: "Integrity Monitoring",
};
