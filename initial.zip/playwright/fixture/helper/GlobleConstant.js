export const moduleMetadata = {
  user: "admin",
};

export const lctr = {
  loginUsername: "Username",
  loginPassword: "Password",
  loginSubmitBtn: "button[type='submit']",
  selectApiBar: "select[id='selectAPIBar']",
};
