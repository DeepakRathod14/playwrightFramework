// @ts-check
const { test, expect } = require("@playwright/test");
import { lctr, text } from "../helper/constant";

test.describe(
  "Modules > Security Information Management > Security Event Test Cases",
  { tag: "@Regression" },
  () => {
    test.beforeEach("load Page", async ({ page }) => {
      await page.goto("/");
      await page.waitForLoadState("networkidle");
      await page.locator(lctr.appLogoHeader).click();
    });

    test(
      "validate Security Events page",
      { tag: "@Sanity" },
      async ({ page }) => {
        await page
          .getByRole("button", { name: text.Modules, exact: true })
          .click();
        await page.getByRole("button", { name: text.SecurityEvents }).click();
        await expect(page.getByTitle("Security events")).toBeVisible();
      }
    );

    test(
      "validate Integrity Monitoring page",
      { tag: "@Sanity" },
      async ({ page }) => {
        await page
          .getByRole("button", { name: text.Modules, exact: true })
          .click();
        await page
          .getByRole("button", { name: text.IntegrityMonitoring })
          .click();
        await expect(page.getByTitle(text.IntegrityMonitoring)).toBeVisible();
      }
    );
  }
);
