# Playwright Automation

<h4>UI Automation Project for Automation Testing</h4>
For UI Automation we choose playwright (node js based) tool. which offer build-in support of

- Multiuple browsers,
- Manipulate Network calls,
- console logs,
- DOM manipulation,
- Auto wait until element visible
- Debugging scripts on runtime (incude time travel) and many more functionality.

## Table of Contents

- [Prerequisite Software](#PrerequisiteSoftware)
- [Extensions Required For IDE](#ExtensionsRequiredForIDE)
- [Project Description](#ProjectDescription)
- [Contributing](#contributing)
- [License](#license)

## Prerequisite Software

- Node js: download and install Node js version [>=14.21.3](https://nodejs.org/download/release/v14.21.3/). Follow the setup and install it. Post installation verify node version using command: `node --version`
- Npm: this will be downloaded with Node js. No additional setup is required for Npm. Make sure that Npm has following version: 6.14.17. Verify npm version post installtion of node js using following command: `npm --version`
- IDE: [Visual Studio Code](https://code.visualstudio.com/) is the preferred IDE for this project.
- Git: Install the latest version of [Git](https://git-scm.com/download/win).

## Extensions required for IDE

Install below plugins in your IDE:

- JavaScript (ES6) code snippets (charalampos karypidis)
- ESlint (Microsoft)
- Inline Parameters for VSCode (Liam Hammett)
- GitLens — Git supercharged (GitKraken)
- GitHub Copilot (GitHub)
- GitLab Workflow (GitLab)
- Fold Plus (dakara)

## Project Description

### 1. Modules

#### 1.1. Full Project Structure Schema

    .
    ├── .vscode                                      # Custom Snippets
    ├── playwright                                   # Main folder
        ├── e2e                                      # Main Tests folder
          ├── Module_Name                            # Module/Page Folder
                ├── api                              # API Calls needed for tests (Optional)
                    ├── ModuleApi.js
                    └── constants.js
                ├── SubModuleName
                    ├── helper                       # Helpers for Monitors Page
                        ├── constants.js             # Object locators file
                        ├── SubModuleDataHelper.js   # Data Helper class to supply data in tests (Optional)
                        └── SubModuleHelper.js       # Page Helper class for carrying out operations
                    └── specs                        # Test Case files
                        ├── SubModule1.spec.js
                        ├── SubModule2.spec.js
                        └── SubModule3.spec.js
        ├── fixtures                                 # Data supplier for entire respository, should be accessed using cy.fixture()
            ├── data                                 # Contains static data to be loaded
                ├── ENV1_Name
                    ├── api.json
                    └── user-credentials.json
                ├── ENV2_Name
                    ├── api.json
                    └── user-credentials.json
            ├── helper                               # Helpers based on Components
                ├── ApiHelper.js
                ├── ButtonHelper.js
                ├── CommonHelper.js
                ├── DropDownHelper.js
                ├── GridHelper.js
                ├── InputButtonHelper.js
                ├── InputFieldHelper.js
                └── LoginHelper.js
            └── index.js
        ├── support                                  # Extends support to playwright frameworks, by addition, custom commands, etc.
            ├── commands.js
            ├── customCommands.d.ts
            └── e2e.js
        ├── constants.js
        └── tsconfig.json
    ├── utilities                                    # External utilities for communicating test results
        ├── jira
        └── teams-reporter
    ├── .eslintignore
    ├── .eslintrc.json                               # Linting rles
    ├── .gitignore                                   # Folders/Files to be excluded
    ├── .gitlab-ci.yml                               # CI/CD pipeline stages
    ├── playwright.config.js                         # Config file for local development
    ├── extractModuleName.js
    ├── package-lock.json
    ├── package.json                                 # packages repository file (Important)
    └── README.md

- Before start automation, It's important to understand current folder structure
  - playwright: ['It is Roo folder, which contains all automation scripts, setups, hooks, etc']
    - e2e: ['End to End automation are written inside.']
      - feature1: ['Each feature will have it's own folder so it will be easy to identify and for maintanance']
        - helper: ['Contains PageObjects, constant and other feature related helper classes']
        - specs: ['Contains test cases related to that feature']
  - .gitignore: ['If we don't want any file/folder as a part of git commit, we can add into gitignore file.']
  - package-local.json: ['It's use by Node.js for internal use, so we don't need to do anything with this file']
  - package.json: ['It is use for defining any dependancies, add execution commands, and project related information']
  - playwright.config.js: ['It is main configuration file, where entire project configurations are defined']

## Contributing

- Before commiting anything make sure
  - Project Build successfull
  - No any linting issues
  - commited testcases, files should work as expected.
  - No repeated code
- For commiting any code follow the below steps
  - git status [check the status of the code]
  - git add . [if anything needs to add, add those changes first]
  - git commit -m "[module: featureFolderName] commit message"
  - git pull origin main/master
  - git push origin [orign_branch_name]

## License

Project is belongs to Organization.
