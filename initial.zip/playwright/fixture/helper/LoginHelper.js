import { lctr } from "./GlobleConstant";

class LoginHelper {
  constructor(pageContext) {
    this.page = pageContext;
  }

  async doLogin() {
    await this.page.goto("/");
    await this.page.getByPlaceholder(lctr.loginUsername).fill("admin");

    await this.page
      .getByPlaceholder(lctr.loginPassword)
      .fill("7qGsONRu5IP9?RHd+j4d00XqoNNAO3mt");
    await this.page.locator(lctr.loginSubmitBtn).click();
    await this.page.waitForLoadState("load");
  }
}
export default LoginHelper;
